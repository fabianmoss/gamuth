# Guide to Advanced Music Theory (GAMuTh)



To build `cd docs` and run `make` to see possible target formats. Generally, use `make html` and `make latexpdf`.

[![Documentation Status](https://readthedocs.org/projects/musictheory/badge/?version=latest)](https://musictheory.readthedocs.io/en/latest/?badge=latest)
