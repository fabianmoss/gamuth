# Guide to Advanced Music Theory (GAMuTh)

This package is heavily under construction.
Contact me for further information.

To build `cd docs` and run `make` to see possible target formats. Generally, use `make html` and `make latexpdf`.
